// Railway Infrastructure as Code (.railway/railway.ts)
// Documentação: https://docs.railway.com/infrastructure-as-code
export const web = {
  name: "vectr-cleanroom-studio",
  build: {
    dockerfile: "Dockerfile"
  },
  deploy: {
    startCommand: "node server.js",
    healthcheckPath: "/health"
  }
};
