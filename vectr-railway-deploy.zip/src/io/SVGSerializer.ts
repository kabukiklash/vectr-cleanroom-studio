import { VectorNode } from '../core/SceneGraph';
import { PenTool } from '../tools/PenTool';

export class SVGSerializer {
  static exportToSVG(nodes: VectorNode[], width: number, height: number, bg = '#ffffff'): string {
    const defs: string[] = [];
    const body: string[] = [];

    nodes.forEach((node) => {
      if (!node.visible) return;
      let fillAttr = 'none';
      if (node.fill.enabled) {
        if (node.fill.type === 'solid') {
          fillAttr = node.fill.color;
        } else if (node.fill.type === 'linear-gradient') {
          const gid = `grad_${node.id}`;
          defs.push(
            `<linearGradient id="${gid}" x1="0%" y1="0%" x2="100%" y2="100%">` +
              `<stop offset="0%" stop-color="${node.fill.color}" />` +
              `<stop offset="100%" stop-color="${node.fill.color2 || '#6366f1'}" />` +
            `</linearGradient>`
          );
          fillAttr = `url(#${gid})`;
        }
      }

      const strokeAttr = node.stroke.enabled
        ? `stroke="${node.stroke.color}" stroke-width="${node.stroke.width}" stroke-linecap="${node.stroke.lineCap}" stroke-linejoin="${node.stroke.lineJoin}"`
        : 'stroke="none"';

      if (node.type === 'rect') {
        body.push(
          `<rect x="${node.x}" y="${node.y}" width="${node.width}" height="${node.height}" rx="${node.cornerRadius || 0}" fill="${fillAttr}" ${strokeAttr} opacity="${node.opacity}" />`
        );
      } else if (node.type === 'path' && node.segments) {
        const d = PenTool.toSVGPathData(node.segments, node.closed);
        body.push(`<path d="${d}" fill="${fillAttr}" ${strokeAttr} opacity="${node.opacity}" />`);
      }
    });

    return [
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">`,
      defs.length ? `<defs>${defs.join('\n')}</defs>` : '',
      `<rect width="100%" height="100%" fill="${bg}" />`,
      ...body,
      `</svg>`,
    ].join('\n');
  }
}
