import { BoundingBox } from '../core/Matrix2D';

export interface SnapGuide {
  orientation: 'vertical' | 'horizontal';
  position: number;
  start: number;
  end: number;
}

export class SnapEngine {
  constructor(private threshold = 6) {}

  computeSnap(
    movingBox: BoundingBox,
    staticBoxes: BoundingBox[],
    artboardWidth: number,
    artboardHeight: number
  ): { dx: number; dy: number; guides: SnapGuide[] } {
    let dx = 0;
    let dy = 0;
    const guides: SnapGuide[] = [];

    const targetsX = [0, artboardWidth / 2, artboardWidth];
    const targetsY = [0, artboardHeight / 2, artboardHeight];

    for (const box of staticBoxes) {
      targetsX.push(box.x, box.cx, box.x + box.width);
      targetsY.push(box.y, box.cy, box.y + box.height);
    }

    const movingXPoints = [movingBox.x, movingBox.cx, movingBox.x + movingBox.width];
    const movingYPoints = [movingBox.y, movingBox.cy, movingBox.y + movingBox.height];

    let bestDiffX = this.threshold + 1;
    for (const mx of movingXPoints) {
      for (const tx of targetsX) {
        const diff = tx - mx;
        if (Math.abs(diff) < Math.abs(bestDiffX)) {
          bestDiffX = diff;
          dx = diff;
          guides.push({ orientation: 'vertical', position: tx, start: 0, end: artboardHeight });
        }
      }
    }

    let bestDiffY = this.threshold + 1;
    for (const my of movingYPoints) {
      for (const ty of targetsY) {
        const diff = ty - my;
        if (Math.abs(diff) < Math.abs(bestDiffY)) {
          bestDiffY = diff;
          dy = diff;
          guides.push({ orientation: 'horizontal', position: ty, start: 0, end: artboardWidth });
        }
      }
    }

    return {
      dx: Math.abs(bestDiffX) <= this.threshold ? dx : 0,
      dy: Math.abs(bestDiffY) <= this.threshold ? dy : 0,
      guides,
    };
  }
}
