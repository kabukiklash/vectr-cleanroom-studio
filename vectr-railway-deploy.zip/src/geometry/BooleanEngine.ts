import paper from 'paper';

export type BooleanOp = 'unite' | 'subtract' | 'intersect' | 'exclude';

export class BooleanEngine {
  private scope: paper.PaperScope;

  constructor() {
    this.scope = new paper.PaperScope();
    this.scope.setup(new this.scope.Size(2000, 2000));
  }

  execute(pathDataA: string, pathDataB: string, op: BooleanOp): string {
    const pA = new this.scope.Path(pathDataA);
    const pB = new this.scope.Path(pathDataB);
    let result: paper.PathItem;

    switch (op) {
      case 'unite':
        result = pA.unite(pB);
        break;
      case 'subtract':
        result = pB.subtract(pA);
        break;
      case 'intersect':
        result = pA.intersect(pB);
        break;
      case 'exclude':
        result = pA.exclude(pB);
        break;
    }

    const d = result.pathData;
    pA.remove();
    pB.remove();
    result.remove();
    return d;
  }
}
