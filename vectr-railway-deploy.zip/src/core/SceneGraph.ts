import { BoundingBox, Point2D } from './Matrix2D';

export type NodeType = 'rect' | 'ellipse' | 'polygon' | 'star' | 'path' | 'text' | 'group';
export type NodeJointMode = 'corner' | 'smooth' | 'symmetric';

export interface BezierSegment {
  id: string;
  anchor: Point2D;
  handleIn: Point2D;
  handleOut: Point2D;
  mode: NodeJointMode;
}

export interface FillStyle {
  enabled: boolean;
  type: 'solid' | 'linear-gradient' | 'radial-gradient';
  color: string;
  color2?: string;
  opacity: number;
  gradientAngle?: number;
}

export interface StrokeStyle {
  enabled: boolean;
  color: string;
  width: number;
  opacity: number;
  lineCap: 'butt' | 'round' | 'square';
  lineJoin: 'miter' | 'round' | 'bevel';
  dashArray: number[];
}

export interface ShadowStyle {
  enabled: boolean;
  color: string;
  offsetX: number;
  offsetY: number;
  blur: number;
}

export interface VectorNode {
  id: string;
  name: string;
  type: NodeType;
  visible: boolean;
  locked: boolean;
  opacity: number;
  blendMode: 'normal' | 'multiply' | 'screen' | 'overlay';
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
  cornerRadius?: number;
  pointsCount?: number;
  innerRadiusRatio?: number;
  segments?: BezierSegment[];
  closed?: boolean;
  text?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: string;
  fill: FillStyle;
  stroke: StrokeStyle;
  shadow: ShadowStyle;
  children?: VectorNode[];
}

export class SceneGraph {
  private nodes: VectorNode[] = [];

  constructor(initialNodes: VectorNode[] = []) {
    this.nodes = structuredClone(initialNodes);
  }

  getNodes(): VectorNode[] {
    return this.nodes;
  }

  findById(id: string): VectorNode | undefined {
    return this.nodes.find((n) => n.id === id);
  }

  addNode(node: VectorNode): void {
    this.nodes.push(node);
  }

  updateNode(id: string, patch: Partial<VectorNode>): VectorNode | undefined {
    const idx = this.nodes.findIndex((n) => n.id === id);
    if (idx === -1) return undefined;
    this.nodes[idx] = { ...this.nodes[idx], ...patch };
    return this.nodes[idx];
  }

  removeNodes(ids: Set<string>): void {
    this.nodes = this.nodes.filter((n) => !ids.has(n.id));
  }

  reorder(id: string, direction: 'front' | 'back' | 'forward' | 'backward'): void {
    const idx = this.nodes.findIndex((n) => n.id === id);
    if (idx === -1) return;
    const [node] = this.nodes.splice(idx, 1);
    if (direction === 'front') this.nodes.push(node);
    else if (direction === 'back') this.nodes.unshift(node);
    else if (direction === 'forward') this.nodes.splice(Math.min(this.nodes.length, idx + 1), 0, node);
    else if (direction === 'backward') this.nodes.splice(Math.max(0, idx - 1), 0, node);
  }

  static computeBoundingBox(node: VectorNode): BoundingBox {
    if (node.segments && node.segments.length > 0) {
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      for (const seg of node.segments) {
        minX = Math.min(minX, seg.anchor.x);
        minY = Math.min(minY, seg.anchor.y);
        maxX = Math.max(maxX, seg.anchor.x);
        maxY = Math.max(maxY, seg.anchor.y);
      }
      const width = Math.max(1, maxX - minX);
      const height = Math.max(1, maxY - minY);
      return { x: minX, y: minY, width, height, cx: minX + width / 2, cy: minY + height / 2 };
    }
    return {
      x: node.x,
      y: node.y,
      width: node.width,
      height: node.height,
      cx: node.x + node.width / 2,
      cy: node.y + node.height / 2,
    };
  }
}
