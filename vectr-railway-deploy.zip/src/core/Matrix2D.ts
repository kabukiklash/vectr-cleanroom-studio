export interface Point2D {
  x: number;
  y: number;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
  cx: number;
  cy: number;
}

export class Matrix2D {
  constructor(
    public a = 1,
    public b = 0,
    public c = 0,
    public d = 1,
    public tx = 0,
    public ty = 0
  ) {}

  static identity(): Matrix2D {
    return new Matrix2D(1, 0, 0, 1, 0, 0);
  }

  static translation(tx: number, ty: number): Matrix2D {
    return new Matrix2D(1, 0, 0, 1, tx, ty);
  }

  static scale(sx: number, sy: number, origin: Point2D = { x: 0, y: 0 }): Matrix2D {
    return Matrix2D.translation(origin.x, origin.y)
      .multiply(new Matrix2D(sx, 0, 0, sy, 0, 0))
      .multiply(Matrix2D.translation(-origin.x, -origin.y));
  }

  static rotation(angleDeg: number, origin: Point2D = { x: 0, y: 0 }): Matrix2D {
    const rad = (angleDeg * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);
    return Matrix2D.translation(origin.x, origin.y)
      .multiply(new Matrix2D(cos, sin, -sin, cos, 0, 0))
      .multiply(Matrix2D.translation(-origin.x, -origin.y));
  }

  multiply(m: Matrix2D): Matrix2D {
    return new Matrix2D(
      this.a * m.a + this.c * m.b,
      this.b * m.a + this.d * m.b,
      this.a * m.c + this.c * m.d,
      this.b * m.c + this.d * m.d,
      this.a * m.tx + this.c * m.ty + this.tx,
      this.b * m.tx + this.d * m.ty + this.ty
    );
  }

  applyToPoint(pt: Point2D): Point2D {
    return {
      x: this.a * pt.x + this.c * pt.y + this.tx,
      y: this.b * pt.x + this.d * pt.y + this.ty,
    };
  }

  invert(): Matrix2D {
    const det = this.a * this.d - this.b * this.c;
    if (Math.abs(det) < 1e-10) return Matrix2D.identity();
    const invDet = 1 / det;
    return new Matrix2D(
      this.d * invDet,
      -this.b * invDet,
      -this.c * invDet,
      this.a * invDet,
      (this.c * this.ty - this.d * this.tx) * invDet,
      (this.b * this.tx - this.a * this.ty) * invDet
    );
  }
}
