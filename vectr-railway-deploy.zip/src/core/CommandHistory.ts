import { VectorNode } from './SceneGraph';

export interface HistorySnapshot {
  label: string;
  timestamp: number;
  nodes: VectorNode[];
}

export class CommandHistory {
  private undoStack: HistorySnapshot[] = [];
  private redoStack: HistorySnapshot[] = [];
  private maxLimit = 60;

  push(label: string, nodes: VectorNode[]): void {
    this.undoStack.push({
      label,
      timestamp: Date.now(),
      nodes: structuredClone(nodes),
    });
    if (this.undoStack.length > this.maxLimit) {
      this.undoStack.shift();
    }
    this.redoStack = [];
  }

  undo(currentNodes: VectorNode[]): VectorNode[] | null {
    const prev = this.undoStack.pop();
    if (!prev) return null;
    this.redoStack.push({
      label: prev.label,
      timestamp: Date.now(),
      nodes: structuredClone(currentNodes),
    });
    return structuredClone(prev.nodes);
  }

  redo(currentNodes: VectorNode[]): VectorNode[] | null {
    const next = this.redoStack.pop();
    if (!next) return null;
    this.undoStack.push({
      label: next.label,
      timestamp: Date.now(),
      nodes: structuredClone(currentNodes),
    });
    return structuredClone(next.nodes);
  }
}
