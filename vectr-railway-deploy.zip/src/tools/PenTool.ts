import { Point2D } from '../core/Matrix2D';
import { BezierSegment, VectorNode } from '../core/SceneGraph';

export type PenState = 'idle' | 'placing-anchor' | 'dragging-handles';

export class PenTool {
  private state: PenState = 'idle';
  private segments: BezierSegment[] = [];
  private cursorPos: Point2D | null = null;
  private closeThresholdPx = 10;

  onPointerDown(pt: Point2D, shiftKey = false): { closed: boolean; finishedNode?: Partial<VectorNode> } {
    if (this.segments.length >= 2 && this.isNearFirstAnchor(pt)) {
      const finished = this.finishPath(true);
      return { closed: true, finishedNode: finished };
    }

    const alignedPt = shiftKey && this.segments.length > 0
      ? this.snapAngle45(this.segments[this.segments.length - 1].anchor, pt)
      : pt;

    const newSegment: BezierSegment = {
      id: `seg_${Date.now()}_${this.segments.length}`,
      anchor: { ...alignedPt },
      handleIn: { x: 0, y: 0 },
      handleOut: { x: 0, y: 0 },
      mode: 'corner',
    };

    this.segments.push(newSegment);
    this.state = 'dragging-handles';
    this.cursorPos = alignedPt;
    return { closed: false };
  }

  onPointerMove(pt: Point2D, altKey = false): void {
    this.cursorPos = pt;
    if (this.state !== 'dragging-handles' || this.segments.length === 0) return;

    const active = this.segments[this.segments.length - 1];
    const dx = pt.x - active.anchor.x;
    const dy = pt.y - active.anchor.y;
    const dist = Math.hypot(dx, dy);

    if (dist > 3) {
      active.handleOut = { x: dx, y: dy };
      if (!altKey) {
        active.mode = 'symmetric';
        active.handleIn = { x: -dx, y: -dy };
      } else {
        active.mode = 'corner';
      }
    }
  }

  onPointerUp(): void {
    if (this.state === 'dragging-handles') {
      this.state = 'placing-anchor';
    }
  }

  finishPath(closed = false): Partial<VectorNode> | undefined {
    if (this.segments.length < 2) {
      this.reset();
      return undefined;
    }
    const result: Partial<VectorNode> = {
      type: 'path',
      name: closed ? 'Caminho Fechado' : 'Caminho Bézier',
      segments: structuredClone(this.segments),
      closed,
    };
    this.reset();
    return result;
  }

  reset(): void {
    this.state = 'idle';
    this.segments = [];
    this.cursorPos = null;
  }

  private isNearFirstAnchor(pt: Point2D): boolean {
    if (this.segments.length === 0) return false;
    const first = this.segments[0].anchor;
    return Math.hypot(pt.x - first.x, pt.y - first.y) <= this.closeThresholdPx;
  }

  private snapAngle45(origin: Point2D, target: Point2D): Point2D {
    const dx = target.x - origin.x;
    const dy = target.y - origin.y;
    const dist = Math.hypot(dx, dy);
    const angle = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
    return {
      x: origin.x + Math.cos(angle) * dist,
      y: origin.y + Math.sin(angle) * dist,
    };
  }

  static toSVGPathData(segments: BezierSegment[], closed = false): string {
    if (segments.length === 0) return '';
    const parts: string[] = [`M ${segments[0].anchor.x.toFixed(2)} ${segments[0].anchor.y.toFixed(2)}`];
    for (let i = 1; i < segments.length; i++) {
      parts.push(PenTool.segmentToCubicCommand(segments[i - 1], segments[i]));
    }
    if (closed && segments.length > 1) {
      parts.push(PenTool.segmentToCubicCommand(segments[segments.length - 1], segments[0]));
      parts.push('Z');
    }
    return parts.join(' ');
  }

  private static segmentToCubicCommand(from: BezierSegment, to: BezierSegment): string {
    const hasOut = Math.hypot(from.handleOut.x, from.handleOut.y) > 0.1;
    const hasIn = Math.hypot(to.handleIn.x, to.handleIn.y) > 0.1;
    if (!hasOut && !hasIn) {
      return `L ${to.anchor.x.toFixed(2)} ${to.anchor.y.toFixed(2)}`;
    }
    const cp1x = from.anchor.x + from.handleOut.x;
    const cp1y = from.anchor.y + from.handleOut.y;
    const cp2x = to.anchor.x + to.handleIn.x;
    const cp2y = to.anchor.y + to.handleIn.y;
    return `C ${cp1x.toFixed(2)} ${cp1y.toFixed(2)}, ${cp2x.toFixed(2)} ${cp2y.toFixed(2)}, ${to.anchor.x.toFixed(2)} ${to.anchor.y.toFixed(2)}`;
  }
}
